from tensorflow.keras.models import load_model
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import time
import tensorflow as tf
import cv2
import numpy as np
import matplotlib.pyplot as plt

class model_wrapper:
    def __init__(self, model_path):
        try:
            print(f"Loading model from {model_path}")
            self.model = load_model(model_path, compile=False, custom_objects={ "Dense": self.tf_wrapper})
            self.model.summary()
            print("Model loaded successfully.")
        except Exception as e:
            print(f"Failed to load model: {e}")
            self.model = None # Defines model on load failure

    @staticmethod
    def tf_wrapper(*args, **kwargs):
        config = kwargs.get('config', {})

        # custom bias layer: constant value = log(pos/neg) where
        # pos is number of ai images, neg is number of human-made
        if kwargs.get('name', None) == "dense_1":
            return tf.keras.layers.Dense(
                units=config.get('units', 1),
                activation=config.get('activation', 'sigmoid'),
                use_bias=config.get('use_bias', True),
                kernel_initializer=tf.keras.initializers.get(config.get('kernel_initializer', 'GlorotUniform')),
                bias_initializer=tf.keras.initializers.Constant(value=0.8498341056885719),
                kernel_regularizer=tf.keras.regularizers.get(config.get('kernel_regularizer')),
                bias_regularizer=tf.keras.regularizers.get(config.get('bias_regularizer')),
                activity_regularizer=tf.keras.regularizers.get(config.get('activity_regularizer')),
                kernel_constraint=tf.keras.constraints.get(config.get('kernel_constraint')),
                bias_constraint=tf.keras.constraints.get(config.get('bias_constraint'))
            )
        # regular dense layer 
        else:
            return tf.keras.layers.Dense(
                units=config.get('units', 128),
                activation=config.get('activation', 'relu'),
                use_bias=config.get('use_bias', True),
                kernel_initializer=tf.keras.initializers.get(config.get('kernel_initializer', 'GlorotUniform')),
                bias_initializer=tf.keras.initializers.get(config.get('bias_initializer', 'Zeros')),
                kernel_regularizer=tf.keras.regularizers.get(config.get('kernel_regularizer')),
                bias_regularizer=tf.keras.regularizers.get(config.get('bias_regularizer')),
                activity_regularizer=tf.keras.regularizers.get(config.get('activity_regularizer')),
                kernel_constraint=tf.keras.constraints.get(config.get('kernel_constraint')),
                bias_constraint=tf.keras.constraints.get(config.get('bias_constraint'))
            )

    def get_model(self):
        if self.model is None:
            raise ValueError("Model not loaded.")
        return self.model